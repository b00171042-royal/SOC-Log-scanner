# 1. Configuration & Setup
$ScriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ProjectFolder = Split-Path -Parent $ScriptFolder

# Try access.log in scripts first, then main project folder
$LogFile = Join-Path $ScriptFolder "access.log"
if (-not (Test-Path $LogFile)) {
    $LogFile = Join-Path $ProjectFolder "access.log"
}

$Malicious_Paths = @("/wp-admin", "/phpmyadmin", "/admin", "/.env", "/config.php")
$AlertCount = 0
$DetectedPaths = @()

Write-Host "--- Scanning for Malicious Web Paths ---" -ForegroundColor Green

# 2. Scanning access.log for Malicious Paths
if (Test-Path $LogFile) {
    $LogContent = Get-Content -Path $LogFile

    foreach ($Path in $Malicious_Paths) {
        $PathHits = $LogContent | Select-String -Pattern ([regex]::Escape($Path)) -AllMatches

        if ($PathHits) {
            $HitCount = ($PathHits | ForEach-Object { $_.Matches.Count } | Measure-Object -Sum).Sum
            if ($HitCount -gt 0) {
                $Message = "[!!!] WARNING: Path accessed: $Path - Hits: $HitCount"
                Write-Host $Message -ForegroundColor Magenta
                $DetectedPaths += $Message
                $AlertCount += $HitCount
            }
        }
    }
} else {
    Write-Output "SECTION: WEB PATH ANALYSIS"
    Write-Output "Error: access.log not found. Checked scripts folder and main project folder."
    Write-Output "---------------------------------------"
    return
}

# 3. Risk Level Calculation
$Risk = if ($AlertCount -ge 2) { "High Risk" } elseif ($AlertCount -eq 1) { "Medium Risk" } else { "Low Risk" }

# 4. Modular Output for Master Script
Write-Output "SECTION: WEB PATH ANALYSIS"
Write-Output "Log File Checked: $LogFile"
Write-Output "Suspicious Paths Checked: $($Malicious_Paths -join ', ')"
Write-Output "Total Malicious Path Hits: $AlertCount"
Write-Output "Path Risk Level: $Risk"
Write-Output "Details:"

if ($DetectedPaths.Count -gt 0) {
    foreach ($DetectedPath in $DetectedPaths) {
        Write-Output $DetectedPath
    }
} else {
    Write-Output "No suspicious web path indicators were found."
}

Write-Output "---------------------------------------"
