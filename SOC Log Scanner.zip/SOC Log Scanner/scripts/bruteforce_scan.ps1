# 1. Configuration
$ScriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ProjectFolder = Split-Path -Parent $ScriptFolder

# Try auth.log in main project folder first, then scripts folder
$AuthLog = Join-Path $ProjectFolder "auth.log"
if (-not (Test-Path $AuthLog)) {
    $AuthLog = Join-Path $ScriptFolder "auth.log"
}

$Threshold = 5
$BruteForceUsers = @()
$BruteForceIPs = @()

Write-Host "--- STARTING AUTHENTICATION ANALYSIS ---" -ForegroundColor Cyan

if (-not (Test-Path $AuthLog)) {
    Write-Output "SECTION: BRUTE FORCE AUTHENTICATION ANALYSIS"
    Write-Output "Error: auth.log not found. Checked main project folder and scripts folder."
    Write-Output "---------------------------------------"
    return
}

$AuthContent = Get-Content $AuthLog

# 2. Extract Failed Login Data
Write-Host "Scanning for failed SSH login attempts..." -ForegroundColor Green
$FailedAttempts = $AuthContent | Select-String -Pattern "Failed password for"

# 3. Analyze by Username
Write-Host "`n[Analysis] Failures per Username:" -ForegroundColor Yellow
$UserFailures = $FailedAttempts | ForEach-Object {
    if ($_ -match "for (?:invalid user )?(\S+)") { $Matches[1] }
} | Group-Object | Sort-Object Count -Descending

foreach ($user in $UserFailures) {
    if ($user.Count -ge $Threshold) {
        $Message = "[!!!] BRUTE FORCE ALERT: Username '$($user.Name)' targeted $($user.Count) times!"
        Write-Host $Message -ForegroundColor Red
        $BruteForceUsers += $Message
    } else {
        Write-Host "Info: User '$($user.Name)' had $($user.Count) failed attempts."
    }
}

# 4. Analyze by Source IP
Write-Host "`n[Analysis] Failures per Source IP:" -ForegroundColor Yellow
$IPFailures = $FailedAttempts | ForEach-Object {
    if ($_ -match "from (\b\d{1,3}(\.\d{1,3}){3}\b)") { $Matches[1] }
} | Group-Object | Sort-Object Count -Descending

foreach ($ip in $IPFailures) {
    if ($ip.Count -ge $Threshold) {
        $Message = "[!!!] BRUTE FORCE ALERT: IP $($ip.Name) attempted $($ip.Count) logins!"
        Write-Host $Message -ForegroundColor Red
        $BruteForceIPs += $Message
    }
}

# 5. Risk Level & Reporting
$AlertCount = $BruteForceUsers.Count + $BruteForceIPs.Count
$Risk = if ($AlertCount -ge 2) { "High Risk" } elseif ($AlertCount -eq 1) { "Medium Risk" } else { "Low Risk" }

# 6. Modular Output for Master Script
Write-Output "SECTION: BRUTE FORCE AUTHENTICATION ANALYSIS"
Write-Output "Log File Checked: $AuthLog"
Write-Output "Threshold Set: $Threshold failed attempts"
Write-Output "Total Failed Password Lines: $($FailedAttempts.Count)"
Write-Output "Total High-Frequency Indicators: $AlertCount"
Write-Output "Authentication Risk Level: $Risk"
Write-Output "Details:"

if (($BruteForceUsers.Count + $BruteForceIPs.Count) -gt 0) {
    foreach ($DetectedUser in $BruteForceUsers) {
        Write-Output $DetectedUser
    }
    foreach ($DetectedIP in $BruteForceIPs) {
        Write-Output $DetectedIP
    }
} else {
    Write-Output "No usernames or source IPs exceeded the brute-force threshold."
}

Write-Output "---------------------------------------"
