# 1. Configuration & Setup
$LogFile = "C:\Users\royal\Documents\advscript\Project\scripts\access.log"
$ReportFile = "threat_report.txt"
$Malicious_IPs = @("198.51.100.8", "203.0.113.5")
$AlertCount = 0

Write-Host "--- SOC SCAN STARTING ---" -ForegroundColor Cyan

# 2. Scanning access.log for IPs
if (Test-Path $LogFile) {
    Write-Host "Scanning $LogFile for known malicious threats..." -ForegroundColor Green
    
    # Extract IPs using the regex from your log detector script
    $AllLogIPs = Get-Content $LogFile | 
        Select-String -Pattern '\b\d{1,3}(\.\d{1,3}){3}\b' -AllMatches | 
        ForEach-Object { $_.Matches.Value }
    
    $GroupedIPs = $AllLogIPs | Group-Object | Sort-Object Count -Descending

    # 3. Match logic
    foreach ($item in $GroupedIPs) {
        if ($Malicious_IPs -contains $item.Name) {
            Write-Host "[!!!] WARNING: Malicious IP found: $($item.Name) - Occurrences: $($item.Count)" -ForegroundColor Magenta
            $AlertCount += $item.Count
        }
    }
} else {
    Write-Host "Error: $LogFile not found!" -ForegroundColor Red
    return
}

# 4. Risk Level Calculation (Logic from Image 2)
if ($AlertCount -ge 2) {
    $Risk = "High Risk"
} elseif ($AlertCount -eq 1) {
    $Risk = "Medium Risk"
} else {
    $Risk = "Low Risk"
}

# 5. Generate & Save Report
$ReportContent = @"
SOC REPORT
----------
Log File Checked: $LogFile
Total Malicious Hits: $AlertCount
Risk Level: $Risk
Status: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
"@

$ReportContent | Out-File $ReportFile -Append
Write-Host "`nScan Complete." -ForegroundColor Blue
Write-Host "Risk Level: $Risk" -ForegroundColor Yellow
Write-Host "Report saved to $ReportFile"