# 1. Configuration
$PSScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ScannerFolder = Join-Path $PSScriptRoot "scripts"
$ReportFile = Join-Path $PSScriptRoot "consolidated_threat_report.txt"

# Initialize/Clear the consolidated report
@"
=======================================
       MASTER SOC SECURITY REPORT
       Generated: $(Get-Date)
=======================================

"@ | Out-File $ReportFile

Write-Host "--- SOC AUTOMATION RUNNER STARTING ---" -ForegroundColor Cyan

# 2. Scanner Execution Logic
$ScriptsToRun = @(
    "ip_scanner.ps1",
    "path_scanner.ps1",
    "bruteforce_scan.ps1"
)

foreach ($Script in $ScriptsToRun) {
    if ($Script -eq "bruteforce_scan.ps1") {
        Write-Host "`nPausing 5 seconds before Brute-Force analysis..." -ForegroundColor Gray
        Start-Sleep -Seconds 5
    }

    $FullPath = Join-Path $ScannerFolder $Script

    if (Test-Path $FullPath) {
        Write-Host "Running $Script..." -ForegroundColor Yellow
        & $FullPath | Out-File $ReportFile -Append
    } else {
        $MissingMessage = "Error: Missing $Script at $FullPath"
        Write-Host $MissingMessage -ForegroundColor Red
        Write-Output $MissingMessage | Out-File $ReportFile -Append
    }
}

@"

--- ALL SCANS COMPLETE ---
Consolidated report available at: $ReportFile
"@ | Out-File $ReportFile -Append

Write-Host "`n--- ALL SCANS COMPLETE ---" -ForegroundColor Cyan
Write-Host "Consolidated report available at: $ReportFile"
